﻿
namespace FORMAT_FLASH
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.text_path = new System.Windows.Forms.TextBox();
            this.button_dialog = new System.Windows.Forms.Button();
            this.button_wrt = new System.Windows.Forms.Button();
            this.button_read = new System.Windows.Forms.Button();
            this.groupBox_rw = new System.Windows.Forms.GroupBox();
            this.button_frmt = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.progress = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button_refresh = new System.Windows.Forms.Button();
            this.groupBox_rw.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox2
            // 
            this.richTextBox2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox2.Location = new System.Drawing.Point(12, 12);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(357, 382);
            this.richTextBox2.TabIndex = 2;
            this.richTextBox2.Text = "";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(294, 415);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 34);
            this.button3.TabIndex = 4;
            this.button3.Text = "СТАРТ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // text_path
            // 
            this.text_path.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.text_path.Location = new System.Drawing.Point(25, 86);
            this.text_path.Name = "text_path";
            this.text_path.Size = new System.Drawing.Size(197, 30);
            this.text_path.TabIndex = 6;
            // 
            // button_dialog
            // 
            this.button_dialog.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_dialog.Location = new System.Drawing.Point(25, 46);
            this.button_dialog.Name = "button_dialog";
            this.button_dialog.Size = new System.Drawing.Size(197, 34);
            this.button_dialog.TabIndex = 7;
            this.button_dialog.Text = "выбрать путь";
            this.button_dialog.UseVisualStyleBackColor = true;
            this.button_dialog.Click += new System.EventHandler(this.button_dialog_Click);
            // 
            // button_wrt
            // 
            this.button_wrt.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_wrt.Location = new System.Drawing.Point(25, 122);
            this.button_wrt.Name = "button_wrt";
            this.button_wrt.Size = new System.Drawing.Size(98, 32);
            this.button_wrt.TabIndex = 8;
            this.button_wrt.Text = "запись";
            this.button_wrt.UseVisualStyleBackColor = true;
            this.button_wrt.Click += new System.EventHandler(this.button_OP_Click);
            // 
            // button_read
            // 
            this.button_read.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_read.Location = new System.Drawing.Point(129, 122);
            this.button_read.Name = "button_read";
            this.button_read.Size = new System.Drawing.Size(93, 32);
            this.button_read.TabIndex = 9;
            this.button_read.Text = "чтение";
            this.button_read.UseVisualStyleBackColor = true;
            this.button_read.Click += new System.EventHandler(this.button_OP_Click);
            // 
            // groupBox_rw
            // 
            this.groupBox_rw.Controls.Add(this.button_dialog);
            this.groupBox_rw.Controls.Add(this.button_read);
            this.groupBox_rw.Controls.Add(this.text_path);
            this.groupBox_rw.Controls.Add(this.button_wrt);
            this.groupBox_rw.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox_rw.Location = new System.Drawing.Point(748, 12);
            this.groupBox_rw.Name = "groupBox_rw";
            this.groupBox_rw.Size = new System.Drawing.Size(244, 190);
            this.groupBox_rw.TabIndex = 10;
            this.groupBox_rw.TabStop = false;
            this.groupBox_rw.Text = "чтение и запись";
            // 
            // button_frmt
            // 
            this.button_frmt.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_frmt.Location = new System.Drawing.Point(402, 415);
            this.button_frmt.Name = "button_frmt";
            this.button_frmt.Size = new System.Drawing.Size(161, 34);
            this.button_frmt.TabIndex = 11;
            this.button_frmt.Text = "Форматировать";
            this.button_frmt.UseVisualStyleBackColor = true;
            this.button_frmt.Click += new System.EventHandler(this.button_frmt_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox1.Location = new System.Drawing.Point(375, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(367, 382);
            this.richTextBox1.TabIndex = 12;
            this.richTextBox1.Text = "";
            // 
            // progress
            // 
            this.progress.ForeColor = System.Drawing.Color.Red;
            this.progress.Location = new System.Drawing.Point(569, 415);
            this.progress.Name = "progress";
            this.progress.Size = new System.Drawing.Size(423, 34);
            this.progress.Step = 5;
            this.progress.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progress.TabIndex = 13;
            this.progress.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button_refresh
            // 
            this.button_refresh.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_refresh.Location = new System.Drawing.Point(186, 415);
            this.button_refresh.Name = "button_refresh";
            this.button_refresh.Size = new System.Drawing.Size(102, 34);
            this.button_refresh.TabIndex = 14;
            this.button_refresh.Text = "ОЧИСТИТЬ";
            this.button_refresh.UseVisualStyleBackColor = true;
            this.button_refresh.Click += new System.EventHandler(this.button_refresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 450);
            this.Controls.Add(this.button_refresh);
            this.Controls.Add(this.progress);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button_frmt);
            this.Controls.Add(this.groupBox_rw);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.richTextBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Программа для форматирования, Кульгейко С.А. гр. 10701221";
            this.groupBox_rw.ResumeLayout(false);
            this.groupBox_rw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox text_path;
        private System.Windows.Forms.Button button_dialog;
        private System.Windows.Forms.Button button_wrt;
        private System.Windows.Forms.Button button_read;
        private System.Windows.Forms.GroupBox groupBox_rw;
        private System.Windows.Forms.Button button_frmt;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ProgressBar progress;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button_refresh;
    }
}

