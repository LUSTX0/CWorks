﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibUsbDotNet;
using LibUsbDotNet.Info;
using LibUsbDotNet.Main;
using System.Management;
using System.Threading;
using System.IO;

namespace FORMAT_FLASH
{
    public partial class Form1 : Form
    {
        BackgroundWorker backgroundWorker1;
        ManagementEventWatcher watcher;
        ManagementEventWatcher insertWatcher;
        public bool flag1 = false;
        public string mpath,npath;
        public List<string> result_prop;
        public int mer = 0;
        public Form1()
        {
            InitializeComponent();
            backgroundWorker1 = new BackgroundWorker();
            //watcher = new ManagementEventWatcher(); ////!
            backgroundWorker1.DoWork += backgroundWorker1_DoWork;
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.WorkerSupportsCancellation = true;
            result_prop= new List<string>();
            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.AddExtension = true;
            //worker = new BackgroundWorker();
            //worker.WorkerReportsProgress = true;
            //worker.WorkerSupportsCancellation = true;

            
        }
        
        public enum EventType
        {
            Inserted = 2,
            Removed = 3
        }

        private void Mainer()
        {
            if(watcher != null)
            {
                watcher.Stop();
                watcher.Dispose();
            }
            
            watcher = new ManagementEventWatcher();
            WqlEventQuery query = new WqlEventQuery("SELECT * FROM Win32_VolumeChangeEvent WHERE EventType = 2 or EventType = 3");
            //watcher.Dispose();
            watcher.EventArrived += (s, e) =>
            {
                string driveName = e.NewEvent.Properties["DriveName"].Value.ToString();
                EventType eventType = (EventType)(Convert.ToInt16(e.NewEvent.Properties["EventType"].Value));
                
                string eventName = Enum.GetName(typeof(EventType), eventType);
                string r111 = $"{DateTime.Now}: {driveName} {eventName}";
                result_prop.Add(r111.Trim());
                Console.WriteLine("{0}: {1} {2}", DateTime.Now, driveName, eventName);
                if(!flag1 && eventName == "Inserted")
                {
                    flag1 = true;
                    mpath = driveName;
                }
                else if (flag1  && eventName == "Removed")
                {
                    flag1 = false;
                    mpath =null;
                }
                else if (flag1  && eventName == "Inserted")
                {
                    
                    mpath = driveName;
                }
                
            };

            watcher.Query = query;
            watcher.Start();
            
            //Console.ReadKey();
        }



        //private static List<string> GetHardwareInfo(string WIN32_Class, string ClassItemField)
        //{
        //    List<string> result = new List<string>();

        //    ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM " + WIN32_Class);

        //    try
        //    {
        //        foreach (ManagementObject obj in searcher.Get())
        //        {
        //            result.Add(obj[ClassItemField].ToString().Trim());
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }

        //    return result;
        //}
        //private void OutputResult(string info, List<string> result)
        //{
        //    if (info.Length > 0)
        //        richTextBox2.Text += "\n"+info+"\n";

        //    if (result.Count > 0)
        //    {
        //        for (int i = 0; i < result.Count; ++i)
        //            richTextBox2.Text += "\n" + result[i] + "\n";
                
        //    }
        //}

        private void DeviceInsertedEvent(object sender, EventArrivedEventArgs e)
        {
            ManagementBaseObject instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
            //instance.Properties.
            //result_prop = new List<string>(); 
            //List<string> result_prop = new List<string>();
            foreach (var property in instance.Properties)
            {
                result_prop.Add((property.Name + " = " + property.Value).Trim());
                Console.WriteLine(property.Name + " = " + property.Value);
               // richTextBox2.Text += "\n" + property.Name + " = " + property.Value;
            }
        }

        //private void DeviceRemovedEvent(object sender, EventArrivedEventArgs e)
        //{
        //    ManagementBaseObject instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
        //    foreach (var property in instance.Properties)
        //    {
        //        Console.WriteLine(property.Name + " = " + property.Value);
        //        //richTextBox2.Text += "\n"+property.Name + " = " + property.Value;
        //    }
        //}

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

            if (insertWatcher != null)
            {
                insertWatcher.Stop();
                insertWatcher.Dispose();
            }
            WqlEventQuery insertQuery = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBHub'");

            insertWatcher = new ManagementEventWatcher(insertQuery);
            insertWatcher.EventArrived += new EventArrivedEventHandler(DeviceInsertedEvent);
            insertWatcher.Start();

            //WqlEventQuery removeQuery = new WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBHub'");
            //ManagementEventWatcher removeWatcher = new ManagementEventWatcher(removeQuery);
            //removeWatcher.EventArrived += new EventArrivedEventHandler(DeviceRemovedEvent);
            //removeWatcher.Start();

            // Do something while waiting for events
            //System.Threading.Thread.Sleep(25000);
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    OutputResult("Процессор:", GetHardwareInfo("Win32_Processor", "Name"));          
        //    OutputResult("Производитель:", GetHardwareInfo("Win32_Processor", "Manufacturer"));   
        //    OutputResult("Описание:", GetHardwareInfo("Win32_Processor", "Description"));          
        //    OutputResult("Видеокарта:", GetHardwareInfo("Win32_VideoController", "Name"));           
        //    OutputResult("Видеопроцессор:", GetHardwareInfo("Win32_VideoController", "VideoProcessor"));                       
        //    OutputResult("Версия драйвера:", GetHardwareInfo("Win32_VideoController", "DriverVersion"));                      
        //    OutputResult("Объем памяти (в байтах):", GetHardwareInfo("Win32_VideoController", "AdapterRAM"));                       
        //    OutputResult("Название дисковода:", GetHardwareInfo("Win32_CDROMDrive", "Name"));                      
        //    OutputResult("Буква привода:", GetHardwareInfo("Win32_CDROMDrive", "Drive"));           
        //    OutputResult("Жесткий диск:", GetHardwareInfo("Win32_DiskDrive", "Caption"));                      
        //    OutputResult("Объем (в байтах):", GetHardwareInfo("Win32_DiskDrive", "Size"));
        //    backgroundWorker1.CancelAsync();
        //}

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    richTextBox2.Text = "starting";
        //    backgroundWorker1.RunWorkerAsync();

        //   // backgroundWorker1_DoWork(sender, e);
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            mer++;
            result_prop = null;
            result_prop = new List<string>();
            backgroundWorker1.CancelAsync();
            //watcher.Stop();
            richTextBox2.Text = "Начало работы!";
            Mainer();
            backgroundWorker1.RunWorkerAsync();
            progress.Visible = true;
            timer1.Start();
            //Thread.Sleep(14000);

            //if (result_prop.Count > 0)
            //{
            //    text_path.Text = mpath + @"\";
            //    openFileDialog1.InitialDirectory = mpath + @"\";
            //    for (int i = 0; i < result_prop.Count; ++i)
            //        richTextBox2.Text += "\n" + result_prop[i] + "\n";

            //}
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            progress.PerformStep();
            if (progress.Value == 100)
            {
                timer1.Stop();
                progress.Value = 0;
                if (result_prop.Count > 0)
                {
                    text_path.Text = mpath + @"\";
                    openFileDialog1.InitialDirectory = mpath + @"\";
                    for (int i = 0; i < result_prop.Count; ++i)
                        richTextBox2.Text += "\n" + result_prop[i] + "\n";

                }
                progress.Visible = false;
            }
        }

        private void button_frmt_Click(object sender, EventArgs e)
        {
            try
            {
                if (mpath == null)
                    throw new ArgumentException("Путь не выбран!");
                Form2 f2 = new Form2();
                f2.Owner = this;
                f2.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show("USB накпопитель не обнаружен!");
            }
        }


        private void button_OP_Click(object sender, EventArgs e)
        {
            if (sender == button_read)
            {
                using (System.IO.StreamReader reader = new System.IO.StreamReader(text_path.Text))
                {                    
                    richTextBox1.Text = reader.ReadToEnd();
                    reader.Close();
                }
            }
            else
            {
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(text_path.Text, true))
                {
                    writer.WriteLine(richTextBox1.Text);

                    writer.Close();
                    //richTextBox1.Text = reader1.ReadToEnd();
                }
            }
        }

        private void button_refresh_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            richTextBox2.Clear();
        }

        private void button_dialog_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // получаем выбранный файл
            npath = openFileDialog1.FileName;
            text_path.Text = npath;
        }
    }
}
