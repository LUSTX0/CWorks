﻿
namespace FORMAT_FLASH
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.combo_size = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_q = new System.Windows.Forms.CheckBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_GO = new System.Windows.Forms.Button();
            this.label_syst = new System.Windows.Forms.Label();
            this.combo_SYSTEM = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.combo_razm = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.combo_razmic = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // combo_size
            // 
            this.combo_size.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.combo_size.FormattingEnabled = true;
            this.combo_size.Location = new System.Drawing.Point(33, 39);
            this.combo_size.Name = "combo_size";
            this.combo_size.Size = new System.Drawing.Size(176, 30);
            this.combo_size.TabIndex = 0;
            this.combo_size.SelectedIndexChanged += new System.EventHandler(this.combo_size_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(30, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Буква диска";
            // 
            // checkBox_q
            // 
            this.checkBox_q.AutoSize = true;
            this.checkBox_q.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox_q.Location = new System.Drawing.Point(52, 399);
            this.checkBox_q.Name = "checkBox_q";
            this.checkBox_q.Size = new System.Drawing.Size(249, 26);
            this.checkBox_q.TabIndex = 4;
            this.checkBox_q.Text = "быстрое форматирование";
            this.checkBox_q.UseVisualStyleBackColor = true;
            // 
            // textBox_name
            // 
            this.textBox_name.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name.Location = new System.Drawing.Point(57, 452);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(176, 30);
            this.textBox_name.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(53, 427);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 22);
            this.label3.TabIndex = 7;
            this.label3.Text = "Название раздела";
            // 
            // button_GO
            // 
            this.button_GO.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_GO.Location = new System.Drawing.Point(87, 499);
            this.button_GO.Name = "button_GO";
            this.button_GO.Size = new System.Drawing.Size(154, 30);
            this.button_GO.TabIndex = 8;
            this.button_GO.Text = "ФОРМАТИРОВАТЬ";
            this.button_GO.UseVisualStyleBackColor = true;
            this.button_GO.Click += new System.EventHandler(this.button_GO_Click);
            // 
            // label_syst
            // 
            this.label_syst.AutoSize = true;
            this.label_syst.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_syst.Location = new System.Drawing.Point(26, 209);
            this.label_syst.Name = "label_syst";
            this.label_syst.Size = new System.Drawing.Size(170, 22);
            this.label_syst.TabIndex = 10;
            this.label_syst.Text = "файловая система";
            // 
            // combo_SYSTEM
            // 
            this.combo_SYSTEM.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.combo_SYSTEM.FormattingEnabled = true;
            this.combo_SYSTEM.Items.AddRange(new object[] {
            "NTFS",
            "FAT32"});
            this.combo_SYSTEM.Location = new System.Drawing.Point(35, 234);
            this.combo_SYSTEM.Name = "combo_SYSTEM";
            this.combo_SYSTEM.Size = new System.Drawing.Size(175, 30);
            this.combo_SYSTEM.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(31, 276);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 22);
            this.label4.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(32, 298);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 22);
            this.label5.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(32, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 22);
            this.label2.TabIndex = 14;
            this.label2.Text = "Объем диска";
            // 
            // combo_razm
            // 
            this.combo_razm.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.combo_razm.FormattingEnabled = true;
            this.combo_razm.Location = new System.Drawing.Point(35, 102);
            this.combo_razm.Name = "combo_razm";
            this.combo_razm.Size = new System.Drawing.Size(176, 30);
            this.combo_razm.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(32, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 22);
            this.label6.TabIndex = 16;
            this.label6.Text = "Размер кластера";
            // 
            // combo_razmic
            // 
            this.combo_razmic.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.combo_razmic.FormattingEnabled = true;
            this.combo_razmic.Location = new System.Drawing.Point(35, 177);
            this.combo_razmic.Name = "combo_razmic";
            this.combo_razmic.Size = new System.Drawing.Size(176, 30);
            this.combo_razmic.TabIndex = 15;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 539);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.combo_razmic);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.combo_razm);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_syst);
            this.Controls.Add(this.combo_SYSTEM);
            this.Controls.Add(this.button_GO);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.checkBox_q);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combo_size);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "ФОРМАТИРОВАНИЕ";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_size;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox_q;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_GO;
        private System.Windows.Forms.Label label_syst;
        private System.Windows.Forms.ComboBox combo_SYSTEM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combo_razm;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox combo_razmic;
    }
}