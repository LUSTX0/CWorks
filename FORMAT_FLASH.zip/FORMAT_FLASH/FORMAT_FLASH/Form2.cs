﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibUsbDotNet;
using LibUsbDotNet.Info;
using LibUsbDotNet.Main;
using System.Management;
using System.Threading;
using System.IO;
using System.Diagnostics;

namespace FORMAT_FLASH
{
    public partial class Form2 : Form
    {
        Form1 main_form;
        //main_form = this.Owner as main_f;
        public Form2()
        {
            
            InitializeComponent();
            
            
        }

        private void button_GO_Click(object sender, EventArgs e)
        {
            string s1, s2;
            string f1, f2;
            string siz = "8192";
            try
            {
                if (combo_SYSTEM.SelectedIndex == 1)
                    s1 = "FAT32";
                else
                    s1 = "NTFS";
                if (textBox_name.Text != null)
                    s2 = textBox_name.Text;
                else
                    s2 = "DEFAULT";
                if (combo_razmic.SelectedIndex == 0)
                {
                    siz = "8192";
                }
                else if (combo_razmic.SelectedIndex == 2)
                {
                    siz = "32000";
                }
                else if (combo_razmic.SelectedIndex == 3)
                {
                    siz = "64000";
                }
                else
                {
                    siz = "16000";
                }

                if (checkBox_q.Checked)
                    f1 = @"/q";
                else
                    f1 = "";

                format(f1, s1, s2, main_form.mpath,siz);
                MessageBox.Show("Форматирование выполнено!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            main_form = this.Owner as Form1;
            //this.Owner.BackColor = Color.Aqua;
            DriveInfo di = new DriveInfo(main_form.mpath + @"\");
            double Ffree = ((di.TotalSize / 1024) / 1024)/1024;
            combo_razm.Items.Add(Ffree.ToString("#,##") + " GB");
            combo_size.Items.Add(main_form.mpath + @"\");
            combo_razmic.Items.Add("8192 Б");
            combo_razmic.Items.Add("16 кБ");
            combo_razmic.Items.Add("32 кБ");
            combo_razmic.Items.Add("64 кБ");
            //MessageBox.Show(Ffree.ToString("#,##") + " GB");
        }

        private void format(string type, string filesystem, string labelofdisk, string name,string ziz)
        {   //Create A Batch File
            StreamWriter w_r;
            w_r = File.CreateText(@"Phoenix.bat");
            w_r.WriteLine("FORMAT "+name+" /y /fs:" + filesystem + " /V:" +labelofdisk + " " + type);
            w_r.WriteLine(labelofdisk);
            w_r.Close();
            //Run Batch File
            System.Diagnostics.Process Proc1 = new System.Diagnostics.Process();
            Proc1.StartInfo.FileName = @"Phoenix.bat";
            Proc1.StartInfo.UseShellExecute = false;
            Proc1.StartInfo.CreateNoWindow = true;
            Proc1.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            Proc1.Start();
            Proc1.WaitForExit();
            //Delete Batch File
            File.Delete(@"Phoenix.bat");
        }

        private void combo_size_SelectedIndexChanged(object sender, EventArgs e)
        {
            DriveInfo di = new DriveInfo(main_form.mpath + @"\");
            label4.Text = di.VolumeLabel;
            label5.Text = "Total Size: " + di.TotalSize / (1024 * 1024) + " MB\nDrive Format: " + di.DriveFormat + " \nAvailable: " + di.AvailableFreeSpace / (1024 * 1024) + " MB\n" + di.DriveType;
        }
    }
}
