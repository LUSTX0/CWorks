﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Pril_CW
{
    class PointRecord
    {
        public Point point;
        public int FuncCoeffsNumber;

        public PointRecord(Point point, int funNumber)
        {
            this.point = point;
            this.FuncCoeffsNumber = funNumber;
        }
    }
}
