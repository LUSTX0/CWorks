﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Core;
using System.IO;
using Microsoft.Office.Interop.Word;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing.Imaging;

namespace Pril_CW
{
    class Fern
    {
        PictureBox _fernPictureBox;
        List<PointRecord> points;
        private const float MinX = -6;
        private const float MaxX = 6;
        private const float MinY = 0.1f;
        private const float MaxY = 10;
        private int _pointsNumber = 10000;
        private float[] _probability = new float[4]
        {
            0.01f,
            0.06f,
            0.08f,
            0.85f
        };
        // Матрица коэффициентов
        private float[,] _funcCoef = new float[4, 6]
        {
            //a      b       c      d      e  f
            {0,      0,      0,     0.16f, 0, 0   }, // 1 функция
            {-0.15f, 0.28f,  0.26f, 0.24f, 0, 0.44f},// 2 функция
            {0.2f,  -0.26f,  0.23f, 0.22f, 0, 1.6f}, // 3 функция
            {0.85f,  0.04f, -0.04f, 0.85f, 0, 1.6f}  // 4 функция
        };

        // коэффициент масштабируемости высоты и ширины
        // изображения фрактала для высоты и ширины нашей формы
        private int _width;
        private int _height;
        // Bitmap для папоротника
        private Bitmap _bitmap;
        private Graphics _graph;


        Random rnd = new Random();

        public Fern()
        {
            this._pointsNumber = 200000;
        }




        public Fern(PictureBox pictureBox, int pointsNumber)
        {
            if (pictureBox is null)
            {
                throw new Exception("Ошибка инициализации: PictureBox is null");
            }
            else if (pointsNumber < 0)
            {
                throw new Exception("Ошибка инициализации: PointsNumber < 0");
            }
            _fernPictureBox = pictureBox;
            _pointsNumber = pointsNumber;
            ReveiwPoles();

        }

        //метод, который устанавливает полям значения (Properties)
        public int PointNumber {
            get => _pointsNumber;
            set {
                if (value > 0) _pointsNumber = value;
                ReveiwPoles();
            }
        }

        //Property  для установка PictureBox'a
        public PictureBox PictureBox
        {
            get => _fernPictureBox;
            set
            {
                _fernPictureBox = value;
                ReveiwPoles();
            }
        }

        //Property для цвета фона и папоротника)
        //public Color BackColor { get; set; } = Color.White;
        public Color FernColor { get; set; } = Color.DarkGreen;

        private void ReveiwPoles()
        {
            // вычисляем коэффициент
            _width = (int)(_fernPictureBox.Width / (MaxX - MinX));
            _height = (int)(_fernPictureBox.Height / (MaxY - MinY));
            // создаем Bitmap для папоротника
            _bitmap = new Bitmap(_fernPictureBox.Width, _fernPictureBox.Height);
            // cоздаем новый объект Graphics из указанного Bitmap
            _graph = Graphics.FromImage(_bitmap);
            // устанавливаем фон
            //_graph.Clear(BackColor);

            points = new List<PointRecord>();
            DrawFern();
        }

        public void DrawFern()
        {
            if (_fernPictureBox is null)
            {
                throw new Exception("Папоротнику не выделен PictureBox!");
            }

            float xtemp = 0, ytemp = 0;
            int numF = 0;

            for (int i = 1; i <= _pointsNumber; i++)
            {
                // рандомное число от 0 до 1
                var num = rnd.NextDouble();
                // проверяем какой функцией воспользуемся для вычисления следующей точки
                for (int j = 0; j <= 3; j++)
                {
                    // если рандомное число оказалось меньше или равно
                    // заданного коэффициента вероятности,
                    // задаем номер функции
                    num -= _probability[j];
                    if (num <= 0)
                    {
                        numF = j;
                        break;
                    }
                }
                // вычисляем координаты
                var x = _funcCoef[numF, 0] * xtemp + _funcCoef[numF, 1] * ytemp + _funcCoef[numF, 4];
                var y = _funcCoef[numF, 2] * xtemp + _funcCoef[numF, 3] * ytemp + _funcCoef[numF, 5];

                // сохраняем значения для следующей итерации
                xtemp = x;
                ytemp = y;
                // вычисляем значение пикселя
                x = (int)(xtemp * _width + _fernPictureBox.Width / 2);
                y = (int)(ytemp * _height);
                points.Add(new PointRecord(new System.Drawing.Point((int)x, (int)y),numF));
                // устанавливаем пиксель в Bitmap
                _bitmap.SetPixel((int)x, (int)y, FernColor);
            }
            // Отображаем результат
            _fernPictureBox.Image = _bitmap;
        }

        public void SaveToExcel(System.Drawing.Image img) {
            System.Threading.Tasks.Task task = new System.Threading.Tasks.Task(delegate
            {
                object misValue = System.Reflection.Missing.Value;
                Excel.Application ex = new Excel.Application
                {
                    SheetsInNewWorkbook = 1
                };
                Excel.Workbook workbook = ex.Workbooks.Add(Type.Missing);
                ex.DisplayAlerts = false;
                Excel.Worksheet sheet = (Excel.Worksheet)ex.Worksheets[1];
                sheet.Name = "Hello world";
                sheet.Cells[1, 1] = "Папоротник";
                sheet.Cells[2, 1] = "Функции генерации точки:";
                sheet.Cells[3, 1] = $"1.a = {_funcCoef[0,0]}, b = {_funcCoef[0, 1]}, c = {_funcCoef[0, 2]}, d = {_funcCoef[0, 3]}, e = {_funcCoef[0, 4]}, f = {_funcCoef[0, 5]}";
                sheet.Cells[4, 1] = $"2.a = {_funcCoef[1,0]}, b = {_funcCoef[1, 1]}, c = {_funcCoef[1, 2]}, d = {_funcCoef[1, 3]}, e = {_funcCoef[1, 4]}, f = {_funcCoef[1, 5]}";
                sheet.Cells[5, 1] = $"3.a = {_funcCoef[2,0]}, b = {_funcCoef[2, 1]}, c = {_funcCoef[2, 2]}, d = {_funcCoef[2, 3]}, e = {_funcCoef[2, 4]}, f = {_funcCoef[2, 5]}";
                sheet.Cells[6, 1] = $"4.a = {_funcCoef[3,0]}, b = {_funcCoef[3, 1]}, c = {_funcCoef[3, 2]}, d = {_funcCoef[3, 3]}, e = {_funcCoef[3, 4]}, f = {_funcCoef[3, 5]}";
                sheet.Cells[7, 1] = "X = ax + bx + e; Y = cy + dy + f, где х и у - предыдущие значения";
                sheet.Cells[8, 1] = "Полученные точки";
                sheet.Cells[9, 1] = "X";
                sheet.Cells[9, 2] = "Y";
                sheet.Cells[9, 3] = "Номер коеффициентов";
                int startRowIndex = 10;             
                for (int i = 0; i < this.points.Count; i++)
                {
                    sheet.Cells[startRowIndex + i, 1] = this.points[i].point.X;
                    sheet.Cells[startRowIndex + i, 2] = this.points[i].point.Y;
                    sheet.Cells[startRowIndex + i, 3] = this.points[i].FuncCoeffsNumber;
                }
                string fileName = @"C:\Users\MSI\Desktop\Pril_CW\hello.png";
                img.Save(fileName);
                sheet.Shapes.AddPicture(fileName, MsoTriState.msoFalse, MsoTriState.msoCTrue, 250, 50, this.PictureBox.Width, this.PictureBox.Height);
                File.Delete(fileName);
                ex.Visible = true;
            });
            task.Start();
        }
        public void SaveToWord(System.Drawing.Image pic)
        {
            System.Threading.Tasks.Task saveToWordTask = new System.Threading.Tasks.Task(delegate
            {
                try
                {
                    Word.Application application;
                    Word.Document document;
                    application = new Word.Application();
                    application.Visible = true;
                    document = application.Documents.Add();


                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.Append($"\n\n\n\n\n\n\n\n\n\n\n\n\nПапоротник\n" +
                        $"Функции генерации точки:\n" +
                        $"1.a = {_funcCoef[0, 0]}, b = {_funcCoef[0, 1]}, c = {_funcCoef[0, 2]}, d = {_funcCoef[0, 3]}, e = {_funcCoef[0, 4]}, f = {_funcCoef[0, 5]}\n" +
                        $"1.a = {_funcCoef[1, 0]}, b = {_funcCoef[1, 1]}, c = {_funcCoef[1, 2]}, d = {_funcCoef[1, 3]}, e = {_funcCoef[1, 4]}, f = {_funcCoef[1, 5]}\n" +
                        $"1.a = {_funcCoef[2, 0]}, b = {_funcCoef[2, 1]}, c = {_funcCoef[2, 2]}, d = {_funcCoef[2, 3]}, e = {_funcCoef[2, 4]}, f = {_funcCoef[2, 5]}\n" +
                        $"1.a = {_funcCoef[3, 0]}, b = {_funcCoef[3, 1]}, c = {_funcCoef[3, 2]}, d = {_funcCoef[3, 3]}, e = {_funcCoef[3, 4]}, f = {_funcCoef[3, 5]}\n" +
                         "X = ax + bx + e; Y = cy + dy + f, где х и у - предыдущие значения\n"
                        );
                    
                    document.Content.Text = stringBuilder.ToString();
                    Range range = document.Range(document.Content.Text.Length - 1, document.Content.Text.Length);
                    Word.Table table = document.Tables.Add(range, this.points.Count + 1, 3);
                    table.Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                    table.Cell(1, 1).Range.Text = "X";
                    table.Cell(1, 2).Range.Text = "Y";
                    table.Cell(1, 3).Range.Text = "Номер коэффициентов";
                    for (int i = 0; i < this.points.Count; i++)
                    {
                        table.Cell(2 + i, 1).Range.Text = this.points[i].point.X.ToString();
                        table.Cell(2 + i, 2).Range.Text = this.points[i].point.Y.ToString();
                        table.Cell(2 + i, 3).Range.Text = this.points[i].FuncCoeffsNumber.ToString();
                    }
                    table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleDouble;
                    table.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleInset;
                   
                    //Bitmap bitmap = new Bitmap(pic.Width, pic.Height, PixelFormat.Format32bppArgb);                    
                    //bitmap.MakeTransparent(Color.White);                    
                    //using (Graphics graphics = Graphics.FromImage(bitmap))
                    //{
                    //    graphics.DrawImage(pic, 0, 0);
                    //}
                    //Color replacementColor = Color.White;                    
                    //for (int x = 0; x < bitmap.Width; x++)
                    //{
                    //    for (int y = 0; y < bitmap.Height; y++)
                    //    {
                    //        Color pixelColor = bitmap.GetPixel(x, y);                            
                    //        if (pixelColor.R == 0 && pixelColor.G == 0 && pixelColor.B == 0)
                    //        {
                    //            bitmap.SetPixel(x, y, replacementColor);
                    //        }
                    //    }
                    //}
                    //bitmap.Save(@"C:\Users\MSI\Desktop\Pril_CW\hello.bmp", ImageFormat.Bmp);                           
                    //pic.Dispose();
                    //bitmap.Dispose();

                    pic.Save(@"C:\Users\MSI\Desktop\Pril_CW\hello.bmp", System.Drawing.Imaging.ImageFormat.Bmp); 
                    document.Shapes.AddPicture(@"C:\Users\MSI\Desktop\Pril_CW\hello.bmp", Type.Missing, Type.Missing, 5, 5, Type.Missing, Type.Missing);
                    File.Delete(@"C:\Users\MSI\Desktop\Pril_CW\hello.bmp");
                }
                catch
                {

                }
            });
            saveToWordTask.Start();
        }
    }
}

