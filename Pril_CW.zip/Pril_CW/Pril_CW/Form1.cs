﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Pril_CW
{
    public partial class Form1 : Form
    {
        private string path = @"C:\\Users\\MSI\\Desktop\\Pril_CW\\";

        Fern Fern;
        INIManager manager;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            new OuterProject.BootForm().ShowDialog();
            manager = new INIManager(@"C:\Users\MSI\Desktop\Pril_CW\file.ini");
            Fern = new Fern
            {
                PictureBox = pictureBox1
            };
            ReadINI();
            button1_Click(button1, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IsAdecvateAndReveiwPoles())
            {
                Fern.DrawFern();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (IsAdecvateAndReveiwPoles())
            {
                Fern.SaveToExcel(pictureBox1.Image);
            }
        }

        private bool IsAdecvateAndReveiwPoles()
        {
            if (radioButton1.Checked)
            {
                try
                {


                    if (int.TryParse(textBox1.Text, out int points))
                    {
                        Fern.PointNumber = points;
                    }
                    else
                    {
                        MessageBox.Show("Ввод неадекватен!");
                        return false;
                    }
                }
                catch
                {

                }
            } else
            {
                int points = Client.GetComplexity();
                textBox1.Text = points.ToString();
                Fern.PointNumber = points;

            }
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (IsAdecvateAndReveiwPoles())
            {
                Fern.SaveToWord(pictureBox1.Image);
            }
        }

        private void фонToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            button1_Click(button1, e);
        }

        private void папоротникToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Fern.FernColor = colorDialog1.Color;
            button1_Click(button1, e);
        }

        private void формаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            this.BackColor = colorDialog1.Color;
        }

        private void wordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button3_Click(button3, e);
        }

        private void excelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            button2_Click(button2, e);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveToINI();
        }

        private void SaveToINI()
        {
            manager.WritePrivateString("Value", "NumberValue", textBox1.Text);
            manager.WritePrivateString("Color", "FormColor", this.BackColor.ToArgb().ToString());
            manager.WritePrivateString("Color", "FernColor", Fern.FernColor.ToArgb().ToString());
        }

        private void ReadINI()
        {
            try
            {
                textBox1.Text = manager.GetPrivateString("Value", "NumberValue");
                this.BackColor = Color.FromArgb(int.Parse(manager.GetPrivateString("Color", "FormColor")));
                Fern.FernColor = Color.FromArgb(int.Parse(manager.GetPrivateString("Color", "FernColor")));
            }
            catch
            {
                MessageBox.Show("INI-файл был поврежден");
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new OuterProject.About().ShowDialog();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(path + "helper.chm");

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar!=8)
            {
                e.Handled = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox1.Text = "100";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            Process.Start("C:\\Users\\MSI\\Desktop\\Pril_CW\\Server\\bin\\Debug\\Server.exe");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button6.Enabled = true;

            if(pictureBox1.Image != null)
            {
                pictureBox1.Image.Save("C:\\Users\\MSI\\Desktop\\Pril_CW\\image.png");
            }
            File.Delete("C:\\Users\\MSI\\Desktop\\Pril_CW\\image1.png");
            File.Copy(Path.Combine("C:\\Users\\MSI\\Desktop\\Pril_CW\\image.png"), 
                Path.Combine("C:\\Users\\MSI\\Desktop\\Pril_CW\\image1.png"));

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Process.Start("C:\\Users\\MSI\\Desktop\\Pril_CW\\DragonCurve\\bin\\Debug\\DragonCurve.exe");
        }

        private void справкаToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void цветToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void aboutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            new OuterProject.About().ShowDialog();
            //MessageBox.Show("Кульгейко Степан Александрович\n\tгр. 10701221\n\t2023");
        }
    }
}
