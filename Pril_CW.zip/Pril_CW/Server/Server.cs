﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class Server
    {
        private const string defaultGateway = "127.0.0.5";
        private const int PORT = 8506;
        private const int SIZE = 1024;
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Сервер запущен...\n");
                IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Parse(defaultGateway), PORT);
                Socket s1 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                s1.Bind(ipEndPoint); // Связываем объёкт Socket с локальной конечной точкой 
                s1.Listen(1); // Устанавливаем объект Socket в состояние прослушивания, 
                              // задаем количество клиентов, ожидающих в очередфи
                Console.WriteLine("\tSERVER INFORMATION\n");
                Console.WriteLine("Descriptor\t: " + s1.Handle);
                Console.WriteLine("\nIPv4\t\t: " + ipEndPoint.Address.ToString());
                Console.WriteLine("\nPort\t\t: " + PORT + Environment.NewLine);
                Thread.Sleep(1000);
                while (true)
                {
                    Console.WriteLine("\nСервер ждёт подключения клиентов: ");
                    //ПРограмма приостанавливается, ожидая входящее соединение
                    Socket s2 = s1.Accept(); // Извлекает из очередиоиждающих запросов первый запрос на соединение и создает для его обработки новый соект

                    Console.WriteLine("\nПолучен запрос от клиента на установление соединения:\n");

                    //декодируем все символы в последовательность байтов

                    Random rnd = new Random();
                    int dataSend = rnd.Next(500, 10001);

                    byte[] byteSend = Encoding.ASCII.GetBytes(dataSend.ToString());
                    //Передаем данные клиенту
                    int lenBytesSend = s2.Send(byteSend);

                    Console.WriteLine("\nПередано клиенту успешно " + lenBytesSend + " байт; ");

                    s2.Shutdown(SocketShutdown.Both); // Блокирует передачу и получение данных
                    s2.Close(); // закрывает подключение Socket и освбождает все связанные ресурсы
                    Console.WriteLine("\nСервер завершил соединение");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.ToString());
            }
            finally
            {
                Console.WriteLine("");
            }
        }
    }
}
