﻿using System;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace RemoteComputerInfoClient
{
    class Program
    {
        static void Main(string[] args)
        {
            int tbb = 1;
            while (tbb != 0)
            {
                Console.WriteLine("1way-be client\n2way-be server\n0-exit");
                tbb = int.Parse(Console.ReadLine());
                switch (tbb)
                {
                    case 0:
                        return;
                    case 1:
                        BeClient.MainCAst();
                        break;
                    case 2:
                        BeServer.MainInfluence();
                        break;
                }

            }
        }
    }

    public class BeClient
    {
        public static void MainCAst()
        {
            int tab = 1;
            while (tab != 0)
            {


                // Connect to the remote server on port 8080

                //TcpClient client = new TcpClient();
                //client.Connect("127.0.0.1", 8080);

                IPAddress[] addresses = Dns.GetHostAddresses("TEST-TOP");
                int port = 1234; // Replace with the desired port number
                TcpClient client = new TcpClient(addresses[1].ToString(), port);
                NetworkStream stream = client.GetStream();
                //byte[] senka = Encoding.ASCII.GetBytes("Hello, deskfddfdftop!");
                //strema.Write(senka, 0, senka.Length);
                //strema.Close();
                //clema.Close();

                //// Get the client stream for reading and writing
                //NetworkStream stream = client.GetStream();

                // Receive the welcome message from the server
                byte[] welcomeMessageBytes = new byte[1024];
                int welcomeMessageBytesRead = stream.Read(welcomeMessageBytes, 0, welcomeMessageBytes.Length);
                string welcomeMessage = Encoding.ASCII.GetString(welcomeMessageBytes, 0, welcomeMessageBytesRead);

                Console.WriteLine(welcomeMessage);

                // Get the requested information from the user
                Console.Write("Enter the information you want to retrieve (hostname/ipaddress/osversion/getinf): ");
                string request = Console.ReadLine();

                // Send the request to the server
                byte[] requestBytes = Encoding.ASCII.GetBytes(request);
                stream.Write(requestBytes, 0, requestBytes.Length);

                // Receive the response from the server
                byte[] responseBytes = new byte[2048];
                int responseBytesRead = stream.Read(responseBytes, 0, responseBytes.Length);
                string response = Encoding.ASCII.GetString(responseBytes, 0, responseBytesRead);

                Console.WriteLine("Response: " + response);

                // Close the client connection
                client.Close();

                Console.WriteLine("enter 0 to end ");
                tab = int.Parse(Console.ReadLine());

            }
            Console.WriteLine("Thank u for playing your life!");
        }
    }

    public class BeServer
    {
        public static void MainInfluence()
        {
            // Listen for incoming connections on port 8080
            TcpListener listener = new TcpListener(IPAddress.Any, 8080);
            listener.Start();

            Console.WriteLine("Server started. Waiting for incoming connections...");

            while (true)
            {
                // Accept a new client connection
                TcpClient client = listener.AcceptTcpClient();

                Console.WriteLine("New client connected from " + ((IPEndPoint)client.Client.RemoteEndPoint).Address);

                // Get the client stream for reading and writing
                NetworkStream stream = client.GetStream();

                // Send a welcome message to the client
                byte[] welcomeMessage = Encoding.ASCII.GetBytes("Welcome to the remote computer info server!");
                stream.Write(welcomeMessage, 0, welcomeMessage.Length);

                // Read the client's request
                byte[] requestBytes = new byte[2048];
                int bytesRead = stream.Read(requestBytes, 0, requestBytes.Length);
                string request = Encoding.ASCII.GetString(requestBytes, 0, bytesRead);

                Console.WriteLine("Client request: " + request);

                // Get the requested information about the remote computer
                string info = "";

                switch (request)
                {
                    case "hostname":
                        info = Dns.GetHostName();
                        break;
                    case "ipaddress":
                        info = GetLocalIPAddress();
                        break;
                    case "osversion":
                        info = Environment.OSVersion.ToString();
                        break;
                    default:
                        info = "Invalid request";
                        break;
                }
                // Environment.
                // Send the requested information to the client
                byte[] responseBytes = Encoding.ASCII.GetBytes(info);
                stream.Write(responseBytes, 0, responseBytes.Length);

                // Close the client connection
                client.Close();

                Console.WriteLine("Client connection closed.");
            }
        }

        static string GetLocalIPAddress()
        {
            string ipAddress = "";

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                    ni.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
                {
                    foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            ipAddress = ip.Address.ToString();
                            break;
                        }
                    }

                    if (!string.IsNullOrEmpty(ipAddress))
                    {
                        break;
                    }
                }
            }

            return ipAddress;
        }
    }
}