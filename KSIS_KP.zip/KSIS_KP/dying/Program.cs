﻿//using System;
//using System.Net;
//using System.Net.NetworkInformation;

//namespace GetComputersInLAN
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            // Get the IP address of the local computer
//            string ipAddress = Dns.GetHostAddresses(Dns.GetHostName())[0].ToString();

//            // Get the network prefix from the IP address
//            string networkPrefix = ipAddress.Substring(0, ipAddress.LastIndexOf(".") + 1);

//            // Get the list of all connected devices in the local network
//            NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces();
//            foreach (NetworkInterface adapter in adapters)
//            {
//                // Only consider Ethernet network interfaces
//                if (adapter.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
//                {
//                    // Get the IP properties for this network interface
//                    IPInterfaceProperties ipProperties = adapter.GetIPProperties();

//                    // Iterate over the list of unicast IP addresses for this interface
//                    foreach (UnicastIPAddressInformation unicastAddress in ipProperties.UnicastAddresses)
//                    {
//                        // Only consider IPv4 addresses on the local network
//                        if (unicastAddress.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
//                            unicastAddress.Address.ToString().StartsWith(networkPrefix))
//                        {
//                            // Print the name of the device
//                            Console.WriteLine(unicastAddress.Address.ToString());
//                        }
//                    }
//                }
//            }

//            Console.ReadLine();
//        }
//    }
//}

//using System;
//using System.IO;
//using System.DirectoryServices;
//using System.DirectoryServices.ActiveDirectory;
//using System.Reflection.PortableExecutable;
//using DirectoryEntry = System.DirectoryServices.DirectoryEntry;

//namespace dying
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            // Get the domain
//            Domain domain = Domain.GetCurrentDomain();

//            // Get the domain's directory entry
//            DirectoryEntry directoryEntry = domain.GetDirectoryEntry();

//            // Get the domain's directory searcher
//            DirectorySearcher directorySearcher = new DirectorySearcher(directoryEntry);

//            // Set the filter to get all computers
//            directorySearcher.Filter = "(&(objectClass=computer))";

//            // Set the properties to load
//            directorySearcher.PropertiesToLoad.Add("name");
//            directorySearcher.PropertiesToLoad.Add("dNSHostName");

//            // Perform the search and get the results
//            SearchResultCollection searchResults = directorySearcher.FindAll();

//            // Display the personal names of all computers
//            foreach (SearchResult searchResult in searchResults)
//            {
//                string computerName = (string)searchResult.Properties["name"][0];
//                string personalName = (string)searchResult.Properties["dNSHostName"][0];
//                Console.WriteLine("{0} : {1}", computerName, personalName);
//            }
//        }
//    }
//}


using System;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;

namespace GetComputerNamesInLAN
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> computerNames = new List<string>();

            // Get IP addresses of all network interfaces
            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface networkInterface in interfaces)
            {
                if (networkInterface.OperationalStatus == OperationalStatus.Up)
                {
                    IPInterfaceProperties properties = networkInterface.GetIPProperties();
                    foreach (UnicastIPAddressInformation address in properties.UnicastAddresses)
                    {
                        if (address.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            string ipAddress = address.Address.ToString();
                            int lastDotIndex = ipAddress.LastIndexOf('.');
                            if (lastDotIndex != -1)
                            {
                                // Build the IP address of the broadcast address for the subnet
                                string broadcastAddress = ipAddress.Substring(0, lastDotIndex) + ".255";
                                IPAddress broadcastIPAddress = IPAddress.Parse(broadcastAddress);

                                // Send an ICMP Echo Request to the broadcast address to discover active hosts
                                Ping pingSender = new Ping();
                                PingOptions options = new PingOptions
                                {
                                    DontFragment = true,
                                    Ttl = 128
                                };
                                byte[] buffer = new byte[32];
                                PingReply reply = pingSender.Send(broadcastIPAddress, 1000, buffer, options);

                                string computerName = GetComputerName("172.0.0.1");
                                computerNames.Add(computerName);

                               

                                //if (reply.Status == IPStatus.Success)
                                //{
                                //    string computerName = GetComputerName(reply.Address.ToString());
                                //    if (!string.IsNullOrEmpty(computerName) && !computerNames.Contains(computerName))
                                //    {
                                //        computerNames.Add(computerName);
                                //    }
                                //}
                            }
                        }
                    }
                }
            }

            // Display the list of computer names
            Console.WriteLine("List of computer names in the LAN:");
            foreach (string computerName in computerNames)
            {
                Console.WriteLine(computerName);
            }
            Console.Write("omg..");
            Console.ReadKey();
        }

        static string GetComputerName(string ipAddress)
        {
            try
            {
                IPHostEntry hostEntry = Dns.GetHostEntry(ipAddress);
                return hostEntry.HostName;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}