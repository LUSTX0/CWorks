﻿using System;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace DISTATNT_IPCONFIG
{       
    public class Starting
    {
        private static Task<List<string>> task;
        public static void StartingExe(Form1 axe)
        {
            List<string> names = new List<string>();
            int tbb = 1;
            while (tbb != 0)
            {
                task = Task.Run(() => GetLocalAddress());                
                Server server = new Server();
                // Start the server automatically
                Thread serverThread = new Thread(() => server.Start(axe));
                serverThread.Start();

                while (true)
                {
                    names = task.Result;
                    task = Task.Run(() => GetLocalAddress());
                    axe.ClearComboBoxIP();
                    foreach (string name in names)
                    {
                        axe.AddItemToComboBoxIP(name);
                    }
                    Thread.Sleep(15000);
                    
                }

                //names = task.Result;
                //axe.IP_List.Items.Clear();
                //foreach (string name in names)
                //{
                //    axe.IP_List.Items.Add(name);
                //}
                //Thread.Sleep(6000);

                // Ask the user if they want to start the client                
                Thread.Sleep(40000);
                // Stop the server
                server.Stop(axe);
                serverThread.Join();
            }
        }

        public static void StartClient(Form1 axe)
        {
            // Ask the user if they want to start the client                       
            Client client = new Client();           
            int counter = 0;
            counter = axe.IP_List.SelectedIndex;
            // Start the client in a separate thread            
            Thread clientThread = new Thread(() => client.ConnectViaCommand(axe.GetSelectedComboBoxItemIP(), axe));
            clientThread.Start();

            // Wait for the user to press a key to disconnect the client
            Thread.Sleep(6000);          

            //client.Disconnect(axe);//*******************
            //clientThread.Join();//****************
            
        }

        private static string GetComputerNameFromIPAddress(string ipAddress)
        {
            try
            {
                var hostEntry = Dns.GetHostEntry(ipAddress);
                return hostEntry.HostName;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }

        public static List<string> GetLocalAddress()
        {

            ProcessStartInfo psi = new ProcessStartInfo("arp", "-a")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false
            };

            Process p = Process.Start(psi);
            string output = p.StandardOutput.ReadToEnd();
            p.WaitForExit();

            // Parse the output to get the IP addresses
            string[] lines = output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            string lip = GetLocalIPAddress();
            List<string> aces = new List<string>();

            foreach (string line in lines)
            {
                string[] tokens = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length == 3 && IPAddress.TryParse(tokens[0], out IPAddress ipAddress))
                {
                    if (ipAddress.ToString().Split('.')[0] == lip.Split('.')[0] && ipAddress.ToString().Split('.')[1] == lip.Split('.')[1] && ipAddress.ToString().Split('.')[2] == lip.Split('.')[2])
                    {
                        aces.Add(ipAddress.ToString());
                    }
                }
            }
            List<string> faces = new List<string>();
            foreach (string line in aces)
            {
                string computerName = GetComputerNameFromIPAddress(line);
                if (!string.IsNullOrWhiteSpace(computerName))
                {
                    faces.Add(computerName);
                }
                else
                {
                    faces.Add(line);
                }
            }

            return faces;
        }
    }
}
