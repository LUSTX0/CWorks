﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DISTATNT_IPCONFIG
{
    public class Server
    {
        private TcpListener _listener;
        private bool _isRunning;

        public void Start(Form1 axe)
        {
            _isRunning = true;
            _listener = new TcpListener(IPAddress.Any, 1234);
            _listener.Start();
            axe.AddText("\nСервер запущен.");
            try
            {
                while (_isRunning)
                {
                    TcpClient client = _listener.AcceptTcpClient();
                    axe.AddText("\nНовый клиент подключен из " + ((IPEndPoint)client.Client.RemoteEndPoint).Address);
                    // Handle client connection in a separate thread
                    Thread thread = new Thread(()=>HandleClient(client,axe));
                    thread.Start();  //maybe client
                }
            }
            catch (SocketException ex) when (ex.ErrorCode == 10004)
            {
                return;
            }

        }

        private void HandleClient(object obj,Form1 axe)
        {
            TcpClient client = (TcpClient)obj;
            NetworkStream stream = client.GetStream();
            // Send a welcome message to the client
            //тут добавить две строки
            byte[] welcomeMessage = Encoding.ASCII.GetBytes("Welcome to the remote computer information server!");
            stream.Write(welcomeMessage, 0, welcomeMessage.Length);

            // Read the client's request
            byte[] requestBytes = new byte[1024];
            int bytesRead = stream.Read(requestBytes, 0, requestBytes.Length);
            string request = Encoding.ASCII.GetString(requestBytes, 0, bytesRead);
            string fRequest="";
            
            // Get the requested information about the remote computer
            string info = "";

            switch (request)
            {
                case "hostname":
                    info = Dns.GetHostName();
                    fRequest = "Имя устройства";
                    break;
                case "ipaddress":
                    info = GetLocalIPAddress();
                    fRequest = "IP-адрес";
                    break;
                case "osversion":
                    info = Environment.OSVersion.ToString();
                    fRequest = "Версия ОС";
                    break;
                case "getinf":
                    info = GetVeryInterestingInfo();
                    fRequest = "Подробная сетевая конфигурация";
                    break;
                default:
                    info = "Некорректный запрос";
                    fRequest = "Некорректный запрос";
                    break;
            }
            axe.AddText("\nКлиентский запрос: " + fRequest);
            // Environment.
            // Send the requested information to the client
            byte[] responseBytes = Encoding.ASCII.GetBytes(info);
            stream.Write(responseBytes, 0, responseBytes.Length);
            // Close the client connection
            client.Close();
            axe.AddText("\nКлиент разорвал соединение.");
            // Handle client requests
            // ...

            //client.Close();
            //Console.WriteLine("Client disconnected.");
        }

        public void Stop(Form1 axe)
        {
            _isRunning = false;
            _listener.Stop();
            axe.AddText("\nСервер остановлен.");
        }

        static string GetLocalIPAddress()
        {
            string ipAddress = "";

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                    ni.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
                {
                    foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            ipAddress = ip.Address.ToString();
                            break;
                        }
                    }

                    if (!string.IsNullOrEmpty(ipAddress))
                    {
                        break;
                    }
                }
            }

            return ipAddress;
        }
        static string GetVeryInterestingInfo()
        {
            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();
            // loop through each network interface
            string cast = "";
            foreach (NetworkInterface ni in interfaces)
            {
                cast += "\nInterface name: " + ni.Name;
                cast += "\nInterface name: " + ni.NetworkInterfaceType.ToString();
                IPInterfaceProperties ipProps = ni.GetIPProperties();
                IPv6InterfaceProperties ipv6Props = ipProps.GetIPv6Properties();

                foreach (UnicastIPAddressInformation addr in ipProps.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        cast += "\nIPv4 address: " + addr.Address.ToString();
                        cast += "\nSubnet mask: " + addr.IPv4Mask.ToString();
                    }
                }

                // IPv6 addresses
                foreach (UnicastIPAddressInformation addr in ipProps.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                    {
                        cast += "\nIPv6 address: " + addr.Address.ToString();
                        cast += "\nSubnet mask: " + addr.PrefixLength;
                    }
                }

                // Default gateway(s)
                foreach (GatewayIPAddressInformation gw in ipProps.GatewayAddresses)
                {
                    cast += "\nDefault gateway: " + gw.Address.ToString();
                    //cast += "\nInterface type: " + ni.NetworkInterfaceType.ToString();
                    //Console.WriteLine("Default gateway: " + gw.Address.ToString());
                }

                cast += "\n";
            }
            return cast;
        }
    }
}
