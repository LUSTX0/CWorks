using System.Diagnostics;
using System.Management;
namespace DISTATNT_IPCONFIG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            fsize.Add(groupMain.Location.X);
            fsize.Add(groupMain.Location.Y);
        }
        delegate void AddTextCallback(string text);
        List<int> fsize = new List<int>();
        public void AddText(string text)
        {
            if (mainTextBox.InvokeRequired)
            {
                // �������� ������� �� ������, ������� ������ ������� TextBox
                AddTextCallback callback = new AddTextCallback(AddText);
                Invoke(callback, new object[] { text });
            }
            else
            {
                // ��������� ����� � ������� TextBox
                mainTextBox.AppendText(text);
            }
        }

        public void AddItemToComboBoxIP(string item)
        {
            if (IP_List.InvokeRequired)
            {
                IP_List.Invoke(new Action<string>(AddItemToComboBoxIP), item);
                return;
            }
            IP_List.Items.Add(item);
        }
        public string GetSelectedComboBoxItemIP()
        {
            if (IP_List.InvokeRequired)
            {
                return (string)IP_List.Invoke(new Func<string>(GetSelectedComboBoxItemIP));
            }
            if (IP_List.SelectedItem == null)
            {
                MessageBox.Show("����������, �������� ������������ ����������");
                return "fault";
            }
            return IP_List.SelectedItem.ToString();
        }

        public string GetSelectedComboBoxItemCommand()
        {
            if (CommandList.InvokeRequired)
            {
                return (string)CommandList.Invoke(new Func<string>(GetSelectedComboBoxItemCommand));
            }
            return CommandList.SelectedItem.ToString();
        }
        public string GetSelectedComboBoxItemCommandND()
        {
            if (CommandList.InvokeRequired)
            {
                return (string)CommandList.Invoke(new Func<string>(GetSelectedComboBoxItemCommandND));
            }
            return CommandList.SelectedIndex.ToString();
        }
        public void ClearComboBoxIP()
        {
            if (IP_List.InvokeRequired)
            {
                IP_List.Invoke(new Action(() => IP_List.Items.Clear()));
            }
            else
            {
                IP_List.Items.Clear();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            timer_main.Enabled = true;
            Thread serverThread = new Thread(() => Starting.StartingExe(this));
            serverThread.Start();
            //Starting.StartingExe(this);
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            try
            {
                Starting.StartClient(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            if (IP_List.Items.Count != 0 || progress_main.Value == 38)
            {
                timer_main.Enabled = false;
                progress_main.Visible = false;
                label_status.Visible = false;
                StartButton.Visible = true;
            }
            else
            {
                progress_main.PerformStep();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

            string processName = "DISTATNT_IPCONFIG.exe";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Process WHERE Name='" + processName + "'");
            ManagementObjectCollection processList = searcher.Get();

            // �������� �� ������ ��������� � ��������� ��
            foreach (ManagementObject obj in processList)
            {
                obj.InvokeMethod("Terminate", null);
            }
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                groupMain.Location = new Point(fsize[0], fsize[1]);
            }
            groupMain.Location = new Point(this.Width / 2 - groupMain.Width / 2, this.Height / 2 - groupMain.Height / 2);
        }


    }
}