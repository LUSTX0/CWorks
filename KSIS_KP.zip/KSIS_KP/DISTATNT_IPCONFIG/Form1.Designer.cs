﻿namespace DISTATNT_IPCONFIG
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            IP_List = new ComboBox();
            CommandList = new ComboBox();
            progress_main = new ProgressBar();
            timer_main = new System.Windows.Forms.Timer(components);
            groupMain = new GroupBox();
            label_status = new Label();
            mainTextBox = new RichTextBox();
            StartButton = new Button();
            groupMain.SuspendLayout();
            SuspendLayout();
            // 
            // IP_List
            // 
            IP_List.BackColor = Color.FromArgb(255, 128, 255);
            IP_List.Font = new Font("Consolas", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            IP_List.FormattingEnabled = true;
            IP_List.Location = new Point(11, 19);
            IP_List.Name = "IP_List";
            IP_List.Size = new Size(282, 32);
            IP_List.TabIndex = 0;
            // 
            // CommandList
            // 
            CommandList.BackColor = Color.FromArgb(255, 128, 255);
            CommandList.Font = new Font("Consolas", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            CommandList.FormattingEnabled = true;
            CommandList.Items.AddRange(new object[] { "имя устройства", "IP-адрес", "версия ОС", "подробная сетевая информация" });
            CommandList.Location = new Point(373, 19);
            CommandList.Name = "CommandList";
            CommandList.Size = new Size(372, 32);
            CommandList.TabIndex = 4;
            // 
            // progress_main
            // 
            progress_main.Location = new Point(11, 12);
            progress_main.Maximum = 38;
            progress_main.Name = "progress_main";
            progress_main.Size = new Size(734, 39);
            progress_main.Step = 1;
            progress_main.TabIndex = 6;
            // 
            // timer_main
            // 
            timer_main.Interval = 500;
            timer_main.Tick += timer1_Tick;
            // 
            // groupMain
            // 
            groupMain.Controls.Add(progress_main);
            groupMain.Controls.Add(CommandList);
            groupMain.Controls.Add(label_status);
            groupMain.Controls.Add(IP_List);
            groupMain.Controls.Add(mainTextBox);
            groupMain.Controls.Add(StartButton);
            groupMain.Location = new Point(1, 0);
            groupMain.Name = "groupMain";
            groupMain.Size = new Size(757, 678);
            groupMain.TabIndex = 9;
            groupMain.TabStop = false;
            // 
            // label_status
            // 
            label_status.BackColor = Color.Transparent;
            label_status.Font = new Font("Consolas", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label_status.ForeColor = Color.Red;
            label_status.Location = new Point(112, 644);
            label_status.Name = "label_status";
            label_status.Size = new Size(466, 24);
            label_status.TabIndex = 11;
            label_status.Text = "Загрузка списка устройств. Подождите..";
            // 
            // mainTextBox
            // 
            mainTextBox.BackColor = Color.FromArgb(255, 192, 255);
            mainTextBox.Font = new Font("Consolas", 14.25F, FontStyle.Italic, GraphicsUnit.Point);
            mainTextBox.Location = new Point(11, 57);
            mainTextBox.Name = "mainTextBox";
            mainTextBox.Size = new Size(734, 587);
            mainTextBox.TabIndex = 10;
            mainTextBox.Text = "";
            // 
            // StartButton
            // 
            StartButton.BackColor = Color.FromArgb(255, 128, 255);
            StartButton.Font = new Font("Consolas", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            StartButton.Location = new Point(307, 640);
            StartButton.Name = "StartButton";
            StartButton.Size = new Size(130, 34);
            StartButton.TabIndex = 9;
            StartButton.Text = "НАЧАТЬ";
            StartButton.UseVisualStyleBackColor = false;
            StartButton.Visible = false;
            StartButton.Click += StartButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 192);
            ClientSize = new Size(758, 677);
            Controls.Add(groupMain);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "GET_IPCONFIG";
            FormClosed += Form1_FormClosed;
            Load += Form1_Load;
            SizeChanged += Form1_Resize;
            groupMain.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private ComboBox comboBox2;
        private RichTextBox richTextBox1;
        public ComboBox IP_List;
        public ComboBox CommandList;
        public ProgressBar progress_main;
        private System.Windows.Forms.Timer timer_main;
        private GroupBox groupMain;
        private Label label_status;
        public RichTextBox mainTextBox;
        public Button StartButton;
    }
}