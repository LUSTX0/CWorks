﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading;


namespace DISTATNT_IPCONFIG
{
    public class Client
    {
        private TcpClient _client;

        public void Connect(string serverAddress, Form1 axe)
        {
            //_client = new TcpClient();
            //_client.Connect(serverAddress, 1234);  


            Console.WriteLine("Подключено к серверу {0}.", serverAddress);

            // Handle server communication
            // ...
            IPAddress[] addresses = Dns.GetHostAddresses(serverAddress);
            int port = 1234; // Replace with the desired port number
            TcpClient _client = new TcpClient(addresses[1].ToString(), port);
            //TcpClient _client = new TcpClient("192.168.100.5", port);
            NetworkStream stream = _client.GetStream();
            //byte[] senka = Encoding.ASCII.GetBytes("Hello, deskfddfdftop!");
            //strema.Write(senka, 0, senka.Length);
            //strema.Close();
            //clema.Close();

            //// Get the client stream for reading and writing
            //NetworkStream stream = client.GetStream();

            // Receive the welcome message from the server
            byte[] welcomeMessageBytes = new byte[1024];
            int welcomeMessageBytesRead = stream.Read(welcomeMessageBytes, 0, welcomeMessageBytes.Length);
            string welcomeMessage = Encoding.ASCII.GetString(welcomeMessageBytes, 0, welcomeMessageBytesRead);

            Console.WriteLine(welcomeMessage);//****************************

            // Get the requested information from the user

            string request = axe.CommandList.SelectedItem.ToString();

            // Send the request to the server
            byte[] requestBytes = Encoding.ASCII.GetBytes(request);
            stream.Write(requestBytes, 0, requestBytes.Length);

            // Receive the response from the server
            byte[] responseBytes = new byte[2048];
            int responseBytesRead = stream.Read(responseBytes, 0, responseBytes.Length);
            string response = Encoding.ASCII.GetString(responseBytes, 0, responseBytesRead);

            Console.WriteLine("Response: " + response);//****************

            // Close the client connection

        }

        public void ConnectViaCommand(string serverAddress, Form1 axe)
        {
            try
            {
                if (serverAddress == "fault")
                {
                    return;
                }
                string request = axe.GetSelectedComboBoxItemCommandND();
                switch (request)
                {
                    case "0":
                        request = "hostname";
                        break;
                    case "1":
                        request = "ipaddress";
                        break;
                    case "2":
                        request = "osversion";
                        break;
                    case "3":
                        request = "getinf";
                        break;
                    default:
                        MessageBox.Show("Действие не выбрано");
                        return;
                }

                axe.AddText($"\nПодключено к серверу {serverAddress}.");
                axe.AddText($"\nВыбрана команда: {axe.GetSelectedComboBoxItemCommand()}.");
                // Handle server communication
                // ...
                IPAddress[] addresses = Dns.GetHostAddresses(serverAddress);
                int port = 1234; // Replace with the desired port number
                TcpClient _client = new TcpClient(addresses[1].ToString(), port);
                NetworkStream stream = _client.GetStream();
                //// Get the client stream for reading and writing           
                // Receive the welcome message from the server
                byte[] welcomeMessageBytes = new byte[1024];
                int welcomeMessageBytesRead = stream.Read(welcomeMessageBytes, 0, welcomeMessageBytes.Length);
                string welcomeMessage = Encoding.ASCII.GetString(welcomeMessageBytes, 0, welcomeMessageBytesRead);
                axe.AddText("\n" + welcomeMessage);
                // Get the requested information from the user
                // Send the request to the server
                byte[] requestBytes = Encoding.ASCII.GetBytes(request);
                stream.Write(requestBytes, 0, requestBytes.Length);
                // Receive the response from the server
                byte[] responseBytes = new byte[2048];
                int responseBytesRead = stream.Read(responseBytes, 0, responseBytes.Length);
                string response = Encoding.ASCII.GetString(responseBytes, 0, responseBytesRead);
                axe.AddText("\nОтвет сервера: " + response);
                // Close the client connection 
            }
            catch
            {
                MessageBox.Show("На выбранном устройстве не запущена программа");
            }
            //string request = axe.GetSelectedComboBoxItemCommand();      **************
            

        }

        public void Disconnect(Form1 axe)
        {
            try
            {
                _client.Close();
                axe.AddText("\nОтключено от сервера.");
                //Console.WriteLine("Disconnected from server.");
            }
            catch
            {
                return;
            }
        }
    }

}
