﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace KSIS_KP
{
    class Program
    {
        private const string ipAddr = "0.0.0.0";
        private const int port = 1100;
        private const int length = 10;
        private const int size = 512;

        static void Main()
        {
            Socket serverSocket = startServer(ipAddr, port, length);
            try
            {
                while (true)
                {
                    Socket klientSocket = waitMessage(serverSocket);
                    String dataRec = getMessage(klientSocket);
                    Console.WriteLine("Получено сообщение от клиента {0}:", dataRec);
                    sendMessage("У Беларусi багата гадзiн :" + DateTime.Now.ToString(), klientSocket);
                    closeConnection(klientSocket);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка" + ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }

        private static Socket startServer(String ipAddress, int portToConnection, int lengthToListen)
        {
            Console.WriteLine("Сервер запущен...\n");
            IPEndPoint iPEndPoint = new IPEndPoint(IPAddress.Parse(ipAddress), portToConnection);
            Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(iPEndPoint);
            serverSocket.Listen(lengthToListen);
            Console.WriteLine("Cлушающий сокет:\n Дескриптор сокета {0}:\nIP-address {1}:\n" + "\n Порт {2}:\n", serverSocket.Handle, iPEndPoint.Address, iPEndPoint.Port);
            return serverSocket;
        }

        private static String getMessage(Socket klientSocket)
        {
            String dataRec = null;
            while (dataRec == null || dataRec.IndexOf("<The End>") < (-1))
            {
                byte[] byteRec = new byte[size];
                int lenBytesReceived = klientSocket.Receive(byteRec);
                dataRec += Encoding.UTF32.GetString(byteRec, 0, lenBytesReceived);
            }
            return dataRec;
        }

        private static Socket waitMessage(Socket serverSocket)
        {
            Console.WriteLine("\n Сервер ждёт подключения клиентов:\n");
            Socket klientSocket = serverSocket.Accept();
            Console.WriteLine("Получен запрос клиента на установление соединения\n" + " Дескриптор {0}:\n IP-address клиентского сокета {1}:\n" + "\n Порт {2}:\n", klientSocket.Handle, ((IPEndPoint)klientSocket.RemoteEndPoint).Address, ((IPEndPoint)klientSocket.RemoteEndPoint).Port);
            return klientSocket;
        }

        private static void sendMessage(String sendData, Socket klientSocket)
        {
            byte[] byteSend = Encoding.UTF32.GetBytes(sendData);
            int lenBytesSend = klientSocket.Send(byteSend);
            Console.WriteLine("Передано клиенту успешно {0} байт", lenBytesSend);
        }
        private static void closeConnection(Socket klientSocket)
        {
            klientSocket.Shutdown(SocketShutdown.Both);
            klientSocket.Close();
            Console.WriteLine("Сервер завершил соединение с клиентом");
        }
    }
}
