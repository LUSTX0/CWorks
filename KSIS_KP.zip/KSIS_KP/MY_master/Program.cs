﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace P2PNetworkApp
{
    public class Server
    {
        private TcpListener _listener;
        private bool _isRunning;

        public void Start()
        {
            _isRunning = true;
            _listener = new TcpListener(IPAddress.Any, 1234);
            _listener.Start();
            Console.WriteLine("Server started.");
            try
            {
                while (_isRunning)
                {
                    //TcpClient client = _listener.AcceptTcpClient();
                    //Console.WriteLine("Client connected from {0}.", client.Client.RemoteEndPoint);
                    TcpClient client = _listener.AcceptTcpClient();

                    Console.WriteLine("New client connected from " + ((IPEndPoint)client.Client.RemoteEndPoint).Address);
                    // Handle client connection in a separate thread
                    Thread thread = new Thread(HandleClient);
                    thread.Start(client);
                }
            }
            catch (SocketException ex) when (ex.ErrorCode == 10004)
            {
                return;
            }

        }

        private void HandleClient(object obj)
        {
            TcpClient client = (TcpClient)obj;
            //NetworkStream stream = client.GetStream();


            NetworkStream stream = client.GetStream();

            // Send a welcome message to the client
            //тут добавить две строки
            byte[] welcomeMessage = Encoding.ASCII.GetBytes("Welcome to the remote computer info server!");
            stream.Write(welcomeMessage, 0, welcomeMessage.Length);

            // Read the client's request
            byte[] requestBytes = new byte[1024];
            int bytesRead = stream.Read(requestBytes, 0, requestBytes.Length);
            string request = Encoding.ASCII.GetString(requestBytes, 0, bytesRead);

            Console.WriteLine("Client request: " + request);

            // Get the requested information about the remote computer
            string info = "";

            switch (request)
            {
                case "hostname":
                    info = Dns.GetHostName();
                    break;
                case "ipaddress":
                    info = GetLocalIPAddress();
                    break;
                case "osversion":
                    info = Environment.OSVersion.ToString();
                    break;
                case "getinf":
                    info = GetVeryInterestingInfo();
                    break;
                default:
                    info = "Invalid request";
                    break;
            }
            // Environment.
            // Send the requested information to the client
            byte[] responseBytes = Encoding.ASCII.GetBytes(info);
            stream.Write(responseBytes, 0, responseBytes.Length);

            // Close the client connection
            client.Close();

            Console.WriteLine("Client connection closed.");
            // Handle client requests
            // ...

            //client.Close();
            //Console.WriteLine("Client disconnected.");
        }

        public void Stop()
        {
            _isRunning = false;
            _listener.Stop();
            Console.WriteLine("Server stopped.");
        }

        static string GetLocalIPAddress()
        {
            string ipAddress = "";

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                    ni.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
                {
                    foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            ipAddress = ip.Address.ToString();
                            break;
                        }
                    }

                    if (!string.IsNullOrEmpty(ipAddress))
                    {
                        break;
                    }
                }
            }

            return ipAddress;
        }
        static string GetVeryInterestingInfo()
        {
            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();


            // loop through each network interface
            string cast = "";
            foreach (NetworkInterface ni in interfaces)
            {

                cast += "\nInterface name: " + ni.Name;
                cast += "\nInterface type: " + ni.NetworkInterfaceType.ToString();
                //Console.WriteLine("Interface name: " + ni.Name);
                // Console.WriteLine("Interface type: " + ni.NetworkInterfaceType.ToString());

                IPInterfaceProperties ipProps = ni.GetIPProperties();
                IPv6InterfaceProperties ipv6Props = ipProps.GetIPv6Properties();

                foreach (UnicastIPAddressInformation addr in ipProps.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        cast += "\nIPv4 address: " + addr.Address.ToString();
                        cast += "\nSubnet mask: " + addr.IPv4Mask.ToString();
                        //Console.WriteLine("IPv4 address: " + addr.Address.ToString());
                        //Console.WriteLine("Subnet mask: " + addr.IPv4Mask.ToString());
                    }
                }

                // IPv6 addresses
                foreach (UnicastIPAddressInformation addr in ipProps.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                    {
                        cast += "\nIPv6 address: " + addr.Address.ToString();
                        cast += "\nSubnet mask: " + addr.PrefixLength;
                        //Console.WriteLine("IPv6 address: " + addr.Address.ToString());
                        // Console.WriteLine("Subnet mask: " + addr.PrefixLength);

                    }
                }

                // Default gateway(s)
                foreach (GatewayIPAddressInformation gw in ipProps.GatewayAddresses)
                {
                    cast += "\nDefault gateway: " + gw.Address.ToString();
                    //cast += "\nInterface type: " + ni.NetworkInterfaceType.ToString();
                    //Console.WriteLine("Default gateway: " + gw.Address.ToString());
                }

                cast += "\n";

                Console.WriteLine();
            }
            return cast;
        }
    }

    public class Client
    {
        private TcpClient _client;

        public void Connect(string serverAddress)
        {
            //_client = new TcpClient();
            //_client.Connect(serverAddress, 1234);  


            Console.WriteLine("Connected to server {0}.", serverAddress);

            // Handle server communication
            // ...
            IPAddress[] addresses = Dns.GetHostAddresses(serverAddress);
            int port = 1234; // Replace with the desired port number
            TcpClient _client = new TcpClient(addresses[1].ToString(), port);
            //TcpClient _client = new TcpClient("192.168.100.5", port);
            NetworkStream stream = _client.GetStream();
            //byte[] senka = Encoding.ASCII.GetBytes("Hello, deskfddfdftop!");
            //strema.Write(senka, 0, senka.Length);
            //strema.Close();
            //clema.Close();

            //// Get the client stream for reading and writing
            //NetworkStream stream = client.GetStream();

            // Receive the welcome message from the server
            byte[] welcomeMessageBytes = new byte[1024];
            int welcomeMessageBytesRead = stream.Read(welcomeMessageBytes, 0, welcomeMessageBytes.Length);
            string welcomeMessage = Encoding.ASCII.GetString(welcomeMessageBytes, 0, welcomeMessageBytesRead);

            Console.WriteLine(welcomeMessage);

            // Get the requested information from the user
            Console.WriteLine("Enter the information you want to retrieve (hostname/ipaddress/osversion/getinf): ");
            string request = Console.ReadLine();

            // Send the request to the server
            byte[] requestBytes = Encoding.ASCII.GetBytes(request);
            stream.Write(requestBytes, 0, requestBytes.Length);

            // Receive the response from the server
            byte[] responseBytes = new byte[2048];
            int responseBytesRead = stream.Read(responseBytes, 0, responseBytes.Length);
            string response = Encoding.ASCII.GetString(responseBytes, 0, responseBytesRead);

            Console.WriteLine("Response: " + response);

            // Close the client connection
            
        }

        public void Disconnect()
        {
            try
            {
                _client.Close();
                Console.WriteLine("Disconnected from server.");
            }
            catch
            {
                return;
            }
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            List<string> names = new List<string>();
            int tbb = 1;
            while (tbb != 0)
            {
                Task<List<string>> task = Task.Run(() => GetLocalAddress());
                
                Console.WriteLine("1way-be client\n0-exit");
                //names = GetLocalAddress();
                tbb = int.Parse(Console.ReadLine());
                Server server = new Server();

                // Start the server automatically
                Thread serverThread = new Thread(server.Start);
                serverThread.Start();

                // Ask the user if they want to start the client
                Console.Write("Do you want to start the client? (y/n) ");
                string input = Console.ReadLine();

                if (input.ToLower() == "y")
                {
                    Client client = new Client();
                    
                    Console.WriteLine("Выберите номер устройства:");int counter = 0;
                    names = task.Result;
                    foreach (string name in names)
                    {
                        Console.WriteLine($"{counter} {name}");
                        counter++;
                    }
                    counter = int.Parse(Console.ReadLine());

                    // Start the client in a separate thread
                    Thread clientThread = new Thread(() => client.Connect(names[counter]));
                    clientThread.Start();

                    // Wait for the user to press a key to disconnect the client
                    for (string a = "1"; a != "0";)
                    {
                        Thread.Sleep(250);
                        a = Console.ReadLine();
                    }
                    //Console.ReadKey(true);

                    client.Disconnect();
                    clientThread.Join();
                }

                // Stop the server
                server.Stop();
                serverThread.Join();

            }

            
        }
        
        private static string GetComputerNameFromIPAddress(string ipAddress)
        {
            try
            {
                var hostEntry = Dns.GetHostEntry(ipAddress);
                return hostEntry.HostName;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }

        public static List<string> GetLocalAddress()
        {

            ProcessStartInfo psi = new ProcessStartInfo("arp", "-a")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false
            };

            Process p = Process.Start(psi);
            string output = p.StandardOutput.ReadToEnd();
            p.WaitForExit();

            // Parse the output to get the IP addresses
            string[] lines = output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            string lip = GetLocalIPAddress();
            List<string> aces = new List<string>();

            foreach (string line in lines)
            {
                string[] tokens = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length == 3 && IPAddress.TryParse(tokens[0], out IPAddress ipAddress))
                {
                    if (ipAddress.ToString().Split('.')[0] == lip.Split('.')[0] && ipAddress.ToString().Split('.')[1] == lip.Split('.')[1] && ipAddress.ToString().Split('.')[2] == lip.Split('.')[2])
                    {
                        aces.Add(ipAddress.ToString());
                    }
                }
            }
            List<string> faces = new List<string>();
            foreach (string line in aces)
            {
                string computerName = GetComputerNameFromIPAddress(line);
                if (!string.IsNullOrWhiteSpace(computerName))
                {
                    faces.Add(computerName);
                }
                else
                {
                    faces.Add(line);
                }
            }
            
            return faces;
        }
    }
}