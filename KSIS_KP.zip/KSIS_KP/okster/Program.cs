﻿using System;
using System.Net;
using System.Net.NetworkInformation;

namespace LANScanner
{
    class Program
    {
        static void Main(string[] args)
        {
            // Get the local computer's IP address
            string localIP = GetLocalIPAddress();

            // Create a list to hold the names of all the computers
            // in the LAN
            var computerNames = new System.Collections.Generic.List<string>();

            // Iterate through all the IPs in the local network
            foreach (var ipAddress in GetAllIPAddressesInLocalNetwork())
            {
                try
                {
                    // Create a new Ping object
                    using (var ping = new Ping())
                    {
                        // Ping the IP address
                        var reply = ping.Send(ipAddress, 100);

                        // If the ping was successful, try to get the computer name
                        if (reply.Status == IPStatus.Success)
                        {
                            string computerName = GetComputerNameFromIPAddress(ipAddress);
                            if (!string.IsNullOrWhiteSpace(computerName))
                            {
                                computerNames.Add(computerName);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error pinging {ipAddress}: {ex.Message}");
                }
            }

            // Print out the list of computer names
            Console.WriteLine($"Computers in the LAN ({localIP}):");
            foreach (string name in computerNames)
            {
                Console.WriteLine(name);
            }
        }

        // Returns the local computer's IP address
        private static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }

        // Returns a list of all the IP addresses in the local network
        private static System.Collections.Generic.IEnumerable<string> GetAllIPAddressesInLocalNetwork()
        {
            string localIP = GetLocalIPAddress();
            string[] parts = localIP.Split('.');
            if (parts.Length != 4)
            {
                throw new Exception("Invalid IP Address");
            }

            string baseIP = parts[0] + "." + parts[1] + "." + parts[2] + ".";
            for (int i = 1; i < 255; i++)
            {
                yield return baseIP + i.ToString();
            }
        }

        // Returns the computer name for the given IP address
        private static string GetComputerNameFromIPAddress(string ipAddress)
        {
            try
            {
                var hostEntry = Dns.GetHostEntry(ipAddress);
                return hostEntry.HostName;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}